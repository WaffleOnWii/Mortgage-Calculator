import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;


public class App implements ActionListener {

    int input = 0;
    JLabel label1;
    JLabel label2;
    JFrame frame;
    JPanel panel;
    JTextField textField;
    int price = 0;
    int termNumber = 0;
    double interestRate = 8.038;
    double output = 0.0;

    JButton button = new JButton("Calculate");
    //button.addActionListener(calculateMortgage());

    public App() {
    
    label1 = new JLabel("Insert your loan amount: ");

    frame = new JFrame();

    textField = new JTextField(20);

    panel = new JPanel();
    panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 10, 30));
    panel.setLayout(new GridLayout(0, 1));
    panel.add(textField);
    

    frame.add(panel, BorderLayout.CENTER);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setTitle("Mortgage Calculator");
    frame.pack();
    frame.setVisible(true);
    }

    public static void main(String[] args) throws Exception 
    {
        new App();
    }


    public double calculateMortgage() 
    {
        price = (int) Double.parseDouble(textField.getText());
        output = (double)(price * (interestRate / 12)) / (1 - Math.pow((1 + (interestRate / 12)), (-termNumber * 12)));
        return output;
    }
    @Override
    public void actionPerformed(ActionEvent arg0)
    {
        // TODO Auto-generated method stub
    }
 }


